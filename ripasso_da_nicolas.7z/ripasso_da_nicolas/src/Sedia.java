public class Sedia {
    private String colore;
    public Sedia(String colore){
        this.colore = colore;
    }
    public String toString(){
        return colore;
    }
}
