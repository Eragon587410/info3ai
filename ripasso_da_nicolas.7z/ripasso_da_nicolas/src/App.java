public class App {
    public static void main(String[] args) throws Exception {
        //persona = nome classe, indirizzo oggetto persona nella classe persona
        Persona cavolo = new Persona();
        // System.out.println(cavolo.nome); solo se public nome è età
        System.out.println(cavolo);
        System.out.println(cavolo.getEtà());
        System.out.println(cavolo.getNome());

        cavolo.setNome("Marconi");
        System.out.println(cavolo);
        cavolo.setEtà(23);
        System.out.println(cavolo);

        Persona cavolo2 = new Persona("ciao", 50);
        System.out.println(cavolo2);


        Sedia s = new Sedia("gialla");
        System.out.println(s.toString());
        
    }
}
